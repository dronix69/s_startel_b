# -*- coding: utf-8 -*-

from . import certificado
from . import cursos
from . import inherit_respartner
from . import inherit_sale
from . import simulador
from . import practicas
from . import compras



